import Vue from 'vue';

// 使用 Event Bus进行非父子组件传值
const bus = new Vue();

export default bus;
